/** 空布局 license by http://eleadmin.com */
import EleEmptyLayout from './src/main';

EleEmptyLayout.install = function (app) {
  app.component(EleEmptyLayout.name, EleEmptyLayout);
};

export default EleEmptyLayout;
