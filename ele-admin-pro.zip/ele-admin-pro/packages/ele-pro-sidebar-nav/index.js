/** 侧边栏双排菜单一级 license by http://eleadmin.com */
import EleProSidebarNav from './src/main';

EleProSidebarNav.install = function (Vue) {
  Vue.component(EleProSidebarNav.name, EleProSidebarNav);
};

export default EleProSidebarNav;
