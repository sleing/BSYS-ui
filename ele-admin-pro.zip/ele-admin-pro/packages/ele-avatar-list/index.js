/** 头像列表组件 license by http://eleadmin.com */
import EleAvatarList from './src/main';

EleAvatarList.install = function (app) {
  app.component(EleAvatarList.name, EleAvatarList);
};

export default EleAvatarList;
