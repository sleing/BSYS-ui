/** 地图位置选择组件 license by http://eleadmin.com */
import EleMapPicker from './src/main';

EleMapPicker.install = function (app) {
  app.component(EleMapPicker.name, EleMapPicker);
}

export default EleMapPicker;
