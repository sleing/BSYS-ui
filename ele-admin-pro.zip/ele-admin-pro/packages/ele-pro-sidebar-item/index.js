/** 侧边栏菜单 item license by http://eleadmin.com */
import EleProSidebarItem from './src/main';

EleProSidebarItem.install = function (Vue) {
  Vue.component(EleProSidebarItem.name, EleProSidebarItem);
};

export default EleProSidebarItem;
