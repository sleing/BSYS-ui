/** 高级表格组件 license by http://eleadmin.com */
import EleProTable from './src/main';

EleProTable.install = function (Vue) {
  Vue.component(EleProTable.name, EleProTable);
};

export default EleProTable;
