/** 标签页 license by http://eleadmin.com */
import EleProTabs from './src/main';

EleProTabs.install = function (Vue) {
  Vue.component(EleProTabs.name, EleProTabs);
};

export default EleProTabs;
