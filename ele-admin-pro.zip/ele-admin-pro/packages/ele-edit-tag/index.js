/** 标签输入框组件 license by http://eleadmin.com */
import EleEditTag from './src/main';

EleEditTag.install = function (app) {
  app.component(EleEditTag.name, EleEditTag);
};

export default EleEditTag;
