/** 标签组件 license by http://eleadmin.com */
import EleTag from './src/main';

EleTag.install = function (app) {
  app.component(EleTag.name, EleTag);
};

export default EleTag;
