/**  ele admin 主题设置抽屉 license by http://eleadmin.com */
import EleProSetting from './src/main';

EleProSetting.install = function (Vue) {
  Vue.component(EleProSetting.name, EleProSetting);
};

export default EleProSetting;
