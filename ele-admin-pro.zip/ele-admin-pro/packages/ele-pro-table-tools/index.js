/** 表格工具按钮组件 license by http://eleadmin.com */
import EleProTableTools from './src/main';

EleProTableTools.install = function (app) {
  app.component(EleProTableTools.name, EleProTableTools);
};

export default EleProTableTools;
