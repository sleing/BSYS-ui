/** 数字动画组件 license by http://eleadmin.com */
import EleIconPicker from './src/main';

EleIconPicker.install = function (app) {
  app.component(EleIconPicker.name, EleIconPicker);
};

export default EleIconPicker;
