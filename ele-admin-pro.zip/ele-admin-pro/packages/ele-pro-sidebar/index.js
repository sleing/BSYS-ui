/** 侧边栏 license by http://eleadmin.com */
import EleProSidebar from './src/main';

EleProSidebar.install = function (Vue) {
  Vue.component(EleProSidebar.name, EleProSidebar);
};

export default EleProSidebar;
