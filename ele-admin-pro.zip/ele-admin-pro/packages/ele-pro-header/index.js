/** 顶栏 license by http://eleadmin.com */
import EleProHeader from './src/main';

EleProHeader.install = function (Vue) {
  Vue.component(EleProHeader.name, EleProHeader);
};

export default EleProHeader;
