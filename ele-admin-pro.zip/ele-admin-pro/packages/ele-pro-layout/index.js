/** ele admin 布局 license by http://eleadmin.com */
import EleProLayout from './src/main';

EleProLayout.install = function (Vue) {
  Vue.component(EleProLayout.name, EleProLayout);
};

export default EleProLayout;
