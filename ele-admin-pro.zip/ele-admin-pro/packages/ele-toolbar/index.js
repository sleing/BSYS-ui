/** 表格工具栏组件 license by http://eleadmin.com */
import EleToolbar from './src/main';

EleToolbar.install = function (Vue) {
  Vue.component(EleToolbar.name, EleToolbar);
};

export default EleToolbar;
